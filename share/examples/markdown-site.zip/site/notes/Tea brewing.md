---
tags:
  - tea
  - howto
created: 2026-04-10
---
# Tea brewing

Green teas like [[Sencha]] need cooler water than [[Black tea|black teas]].

- [x] Warm the pot
- [ ] Weigh the leaves
  - 2 g per cup

> Patience makes the tea.

![[teapot.png]]
