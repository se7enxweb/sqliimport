+++
title = "Sencha"
date = 2026-04-02T12:30:00Z
tags = ["tea", "green"]
description = "A Japanese green tea."
weight = 10
[params]
origin = "Shizuoka"
+++

# Sencha

Steep at 70 °C for **one minute**.

| Water | Time |
|---|---|
| 70 °C | 1 min |
| 80 °C | 30 s |

```
water: 70
```
